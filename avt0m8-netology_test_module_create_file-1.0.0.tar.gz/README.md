# Ansible Collection - avt0m8.netology_test_module_create_file

This is netology practice Ansible Collection with custom create_file module and single task create_file_role role.
